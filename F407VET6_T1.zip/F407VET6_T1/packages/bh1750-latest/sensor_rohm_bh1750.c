/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-4-30     Sanjay_Wu  the first version
 */

#include "sensor_rohm_bh1750.h"
#include "bh1750.h"

#define DBG_ENABLE
#define DBG_LEVEL DBG_LOG
#define DBG_SECTION_NAME  "sensor.rohm.bh1750"
#define DBG_COLOR
#include <rtdbg.h>

#define MSG_POOL_SIZE 2
rt_uint32_t msg_pool[MSG_POOL_SIZE]; // 邮箱的消息
// 初始化邮箱
struct rt_mailbox lightlux_mailbox;

static bh1750_device_t bh1750_create(struct rt_sensor_intf *intf)
{
    bh1750_device_t hdev = rt_malloc(sizeof(bh1750_device_t));

    if (RT_NULL == hdev)
    {
        return RT_NULL;
    }

    bh1750_init(hdev, intf->dev_name);

    return hdev;
}

static rt_size_t bh1750_fetch_data(struct rt_sensor_device *sensor, void *buf, rt_size_t len)
{
    bh1750_device_t hdev = sensor->parent.user_data;
    struct rt_sensor_data *data = (struct rt_sensor_data *)buf;

    if (sensor->info.type == RT_SENSOR_CLASS_LIGHT)
    {
        float light_value;
        light_value = bh1750_read_light(hdev);

        data->type = RT_SENSOR_CLASS_LIGHT;
        data->data.light = (rt_int32_t)(light_value * 10);
        data->timestamp = rt_sensor_get_ts();
    }

    return 1;
}

rt_err_t bh1750_set_power(bh1750_device_t hdev, rt_uint8_t power)
{
    if (power == RT_SENSOR_POWER_NORMAL)
    {
        bh1750_power_on(hdev);
    }
    else if (power == RT_SENSOR_POWER_DOWN)
    {
        bh1750_power_down(hdev);
    }
    else
    {
        return -RT_ERROR;
    }

    return RT_EOK;
}

static rt_err_t bh1750_control(struct rt_sensor_device *sensor, int cmd, void *args)
{
    rt_err_t result = RT_EOK;
    bh1750_device_t hdev = sensor->parent.user_data;

    switch (cmd)
    {
        case RT_SENSOR_CTRL_SET_POWER:
        {
            result = bh1750_set_power(hdev, (rt_uint32_t)args & 0xff);
            break;
        }
        case RT_SENSOR_CTRL_SELF_TEST:
        {
            result =  -RT_EINVAL;
            break;
        }
        default:
        {
            result = -RT_ERROR;
            break;
        }
    }

    return result;
}

static struct rt_sensor_ops sensor_ops =
{
    bh1750_fetch_data,
    bh1750_control
};

int rt_hw_bh1750_init(const char *name, struct rt_sensor_config *cfg)
{
    int result = -RT_ERROR;
    rt_sensor_t sensor = RT_NULL;
    bh1750_device_t hdev = bh1750_create(&cfg->intf);

    sensor = rt_calloc(1, sizeof(struct rt_sensor_device));
    if (RT_NULL == sensor)
    {
        LOG_E("calloc failed");
        return -RT_ERROR;
    }

    sensor->info.type       = RT_SENSOR_CLASS_LIGHT;
    sensor->info.vendor     = RT_SENSOR_VENDOR_UNKNOWN;
    sensor->info.model      = "bh1750_light";
    sensor->info.unit       = RT_SENSOR_UNIT_LUX;
    sensor->info.intf_type  = RT_SENSOR_INTF_I2C;
    sensor->info.range_max  = 65535;
    sensor->info.range_min  = 1;
    sensor->info.period_min = 120;

    rt_memcpy(&sensor->config, cfg, sizeof(struct rt_sensor_config));
    sensor->ops = &sensor_ops;

    result = rt_hw_sensor_register(sensor, name, RT_DEVICE_FLAG_RDWR, hdev);
    if (result != RT_EOK)
    {
        LOG_E("device register err code: %d", result);
        rt_free(sensor);
        return -RT_ERROR;
    }
    else
    {
        LOG_I("light sensor init success");
        return RT_EOK;
    }
}

int bh1750_port(void)
{
    struct rt_sensor_config cfg;

    cfg.intf.dev_name = "i2c1";
    cfg.intf.user_data = (void *)BH1750_ADDR;
    cfg.irq_pin.pin = RT_PIN_NONE;

    rt_hw_bh1750_init("bh1750", &cfg);

    return 0;
}
INIT_APP_EXPORT(bh1750_port);


static void bh1750_thread_entry(void *parameter)
{
    rt_uint32_t lightlux;
    rt_device_t dev = RT_NULL;
    struct rt_sensor_data data;
    rt_size_t res;
    //rt_err_t result = rt_mb_init(&lightlux_mailbox, "lightluxmb", &msg_pool[0], sizeof(msg_pool)/4, RT_IPC_FLAG_PRIO);     //邮箱

    /* 查找bh1750传感器  */
    dev = rt_device_find("li_bh1750");
    if (dev == RT_NULL)
    {
        rt_kprintf("Can't find device:li_bh1750\n");
        return;
    }

    /* 以只读模式打开bh1750 */
    if (rt_device_open(dev, RT_DEVICE_FLAG_RDONLY) != RT_EOK)
    {
        rt_kprintf("open device failed!");
        return;
    }

    while(1)
    {
        /* 从传感器读取一个数据 */
        res = rt_device_read(dev, 0, &data, 1);
        if (1 != res)
        {
            rt_kprintf("read data failed!size is %d", res);
        }
        else
        {
            lightlux = (&data)->data.light / 10;
            show_light = lightlux;
            //rt_mb_send(&lightlux_mailbox, lightlux);
            //rt_kprintf("light:%4d lux\n", (&data)->data.light / 10);
        }
        rt_thread_mdelay(1000);
    }
    rt_device_close(dev);
}

int bh1750_example(void)
{
    rt_thread_t tid;    /* 线程句柄 */
    tid = rt_thread_create("bh1750_thread",
            bh1750_thread_entry,
            RT_NULL,
            1024,
            18,
            20);
    if(tid != RT_NULL)
    {
        /* 线程创建成功，启动线程 */
        rt_thread_startup(tid);
    }

    return 0;
}
INIT_APP_EXPORT(bh1750_example);

