/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-21     Administrator       the first version
 */
#ifndef PACKAGES_DHT11_LATEST_DHT11_SAMPLE_H_
#define PACKAGES_DHT11_LATEST_DHT11_SAMPLE_H_


rt_uint32_t mailbox_temp;
rt_uint32_t mailbox_humi;

struct rt_mailbox mb1;
struct rt_mailbox mb2;
rt_uint32_t mb1_pool[2];  // 邮箱缓冲区
rt_uint32_t mb2_pool[2];  // 邮箱缓冲区

int dht11_read_temp_sample(void);

#endif /* PACKAGES_DHT11_LATEST_DHT11_SAMPLE_H_ */
