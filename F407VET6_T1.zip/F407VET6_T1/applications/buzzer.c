/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-21     Administrator       the first version
 */

#include "buzzer.h"

void buzzer_init(void)
{
    rt_pin_mode(BUZZER_PIN_NUM, PIN_MODE_OUTPUT);
    BUZZER_CLOSE();
}
INIT_DEVICE_EXPORT(buzzer_init);

void BUZZER_OPEN()
{
    rt_pin_write(BUZZER_PIN_NUM, PIN_LOW);
}

void BUZZER_CLOSE()
{
    rt_pin_write(BUZZER_PIN_NUM, PIN_HIGH);
}
