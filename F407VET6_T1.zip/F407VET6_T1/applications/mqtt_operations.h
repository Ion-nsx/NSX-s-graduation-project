/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-10     Administrator       the first version
 */
#include <rtdef.h>

#ifndef APPLICATIONS_ESP8266_H_
#define APPLICATIONS_ESP8266_H_

extern uint8_t mq135_status;
rt_uint32_t show_temp;
rt_uint32_t show_humi;
rt_uint32_t show_light;


void Json_Analysis(unsigned char *json_data);
void mqtt_publish_thread_entry(void *parameter);
void mqtt_pubhumi_thread_entry(void *parameter);
void mqtt_publight_thread_entry(void *parameter);
void mqtt_pubAQI_thread_entry(void *parameter);
#endif /* APPLICATIONS_ESP8266_H_ */

