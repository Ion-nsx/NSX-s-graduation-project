/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-18     Administrator       the first version
 */
//#ifndef APPLICATIONS_UART_READ_H_
//#define APPLICATIONS_UART_READ_H_
//
//void uart_receive_thread(void* parameter);
//
//#endif /* APPLICATIONS_UART_READ_H_ */
