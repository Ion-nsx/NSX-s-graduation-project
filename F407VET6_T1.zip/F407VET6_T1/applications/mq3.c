#include "mq3.h"
#include "buzzer.h"
#include <rtdevice.h>
#define THREAD_PRIORITY         18
#define THREAD_STACK_SIZE       512
#define THREAD_TIMESLICE        5

//PA3
#define ADC_DEV_NAME        "adc1"      /* ADC 设备名称 */
#define ADC_DEV_CHANNEL     3           /* ADC 通道 */
#define REFER_VOLTAGE       500         /* 参考电压 5V,数据精度乘以100保留2位小数*/
#define CONVERT_BITS        (1 << 12)   /* 转换位数为12位 */

uint8_t mq135_status;
uint8_t mq135_value=0;
static rt_mailbox_t  mq3_mb = RT_NULL;
static void mq3_mb_send(rt_uint32_t  data)
{
    rt_mb_send (mq3_mb, data);
}
void mq3_mb_recv(rt_ubase_t *value,rt_uint32_t timeout)
{
    rt_mb_recv (mq3_mb, value, timeout);
}


rt_adc_device_t  adc_dev;
static void mq3_thread_entry(void *parameter)
{
    rt_uint32_t value,vol;


    while(1)
    {
        value = rt_adc_read(adc_dev, ADC_DEV_CHANNEL);
        vol = value * REFER_VOLTAGE / CONVERT_BITS;
        mq135_value = vol%100 ;
        rt_kprintf("mq135= %d \n",mq135_value);
        //rt_kprintf("mq135= %d.%02d \n",vol/100,vol%100);
        if((vol%100)>50) {
            mq135_status=1;
            BUZZER_OPEN();
        }
        else{
            mq135_status=0;
            BUZZER_CLOSE();
        }
        mq3_mb_send(vol);
        rt_thread_mdelay(1000);
    }
}

static rt_thread_t mq3_thread = RT_NULL;
int mq3_init(void)
{ 
    rt_err_t ret = RT_EOK;
    adc_dev = (rt_adc_device_t)rt_device_find(ADC_DEV_NAME);
    if (adc_dev == RT_NULL)
    {
        rt_kprintf("adc sample run failed! can't find %s device!\n", ADC_DEV_NAME);
        return RT_ERROR;
    }
    //使能
    ret = rt_adc_enable(adc_dev, ADC_DEV_CHANNEL);

    mq3_mb = rt_mb_create("mq3_mb", 32, RT_IPC_FLAG_PRIO);
    RT_ASSERT(mq3_mb != RT_NULL);

    mq3_thread = rt_thread_create("mq3_thread",
            mq3_thread_entry, RT_NULL,
            THREAD_STACK_SIZE,
            THREAD_PRIORITY, THREAD_TIMESLICE);
    if (mq3_thread != RT_NULL)
        rt_thread_startup(mq3_thread);
    return ret;
}
INIT_APP_EXPORT(mq3_init);
