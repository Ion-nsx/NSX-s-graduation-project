/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-21     Administrator       the first version
 */
#include <rtthread.h>
#include <rtdevice.h>
#include "drv_common.h"
#include "sensor.h"
#ifndef APPLICATIONS_BUZZER_H_
#define APPLICATIONS_BUZZER_H_

#define BUZZER_PIN_NUM      GET_PIN(C, 8)     //定义蜂鸣器的引脚

void buzzer_init(void);
void BUZZER_OPEN();
void BUZZER_CLOSE();


#endif /* APPLICATIONS_BUZZER_H_ */
