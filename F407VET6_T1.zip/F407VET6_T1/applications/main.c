/*
 * Copyright (c) 2006-2024, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2024-09-04     RT-Thread    first version
 */

#include <rtthread.h>
#include <rtdevice.h>
#include "sensor.h"
#include "drv_common.h"
#include "st7735s.h"
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
#include "uart_read.h"
#include "led.h"
#include "dht11_sample.h"

extern rt_uint32_t show_temp;
extern rt_uint32_t show_humi;
extern rt_uint32_t show_light;
extern  uint8_t LightSwitch;
extern  uint8_t FanSwitch;
extern  uint8_t aliyun_status;
extern uint8_t mq135_value;
int main(void)
{
    LCD_Init();
    LCD_Clear(BLACK);
    LCD_ShowString(10, 5, 128, 160, 16, "Temp:", WHITE, BLACK);
    LCD_ShowString(10, 25, 128, 160, 16, "Humi:", WHITE, BLACK);
    LCD_ShowString(10, 45, 128, 160, 16, "MQ135:", WHITE, BLACK);
    LCD_ShowString(10, 65, 128, 160, 16, "FanStatus:", WHITE, BLACK);
    LCD_ShowString(10, 85, 128, 160, 16, "Conn:", WHITE, BLACK);
    while(1){
        //rt_kprintf("show_temp:%d",show_temp);
        //rt_kprintf("show_humi:%d",show_humi);
        LCD_ShowNum(50,5,show_temp,2,16);
        LCD_ShowNum(50,25,show_humi,2,16);
        LCD_ShowString(58, 45, 128, 160, 16, "0", WHITE, BLACK);
        LCD_ShowString(65, 45, 128, 160, 16, ".", WHITE, BLACK);
        LCD_ShowNum(70,45,mq135_value,2,16);
        if(FanSwitch){
            LCD_ShowString(90, 65, 128, 160, 16, "ON ", WHITE, BLACK);
        }else{
            LCD_ShowString(90, 65, 128, 160, 16, "OFF", WHITE, BLACK);
        }
        if(aliyun_status){
                    LCD_ShowString(60, 85, 128, 160, 16, "Online ", WHITE, BLACK);
                }else{
                    LCD_ShowString(60, 85, 128, 160, 16, "Offline", WHITE, BLACK);
                }
        rt_thread_mdelay(200);
    }

    return RT_EOK;
}
