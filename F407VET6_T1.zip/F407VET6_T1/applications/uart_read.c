#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#define LED1_PIN    GET_PIN(C,12)
#define UART_NAME "uart3" // 定义使用的UART设备名称
#define SUB_TOPIC "/sys/k0we6nvqMvX/DHT11/thing/service/property/set"

#define INA_PIN    GET_PIN(E,8)
#define INB_PIN    GET_PIN(E,9)

uint8_t  LightSwitch=0 ;
uint8_t FanSwitch=0 ;
static struct rt_semaphore rx_sema; // 接收信号量

// 串口接收回调函数
static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&rx_sema); // 释放信号量，通知有数据可读
    return RT_EOK;
}


void uart_receive_and_print(void* parameter)
{
    rt_device_t device;
    char uart_rx_buffer[512]; // 用于存储接收数据的缓冲区
    int length;
    static char accum_buffer[512] = ""; // 累积缓冲区，用于拼接未完成的数据包
    static int accum_length = 0;        // 累积缓冲区中的当前长度

    device = rt_device_find(UART_NAME);
    if (!device)
    {
        rt_kprintf("Failed to find UART device %s!\n", UART_NAME);
        return;
    }

    while (1)
    {
        // 等待信号量，即等待接收数据完成
        rt_sem_take(&rx_sema, RT_WAITING_FOREVER);

        // 从UART设备中读取数据
        length = rt_device_read(device, 0, uart_rx_buffer, sizeof(uart_rx_buffer));

        if (length > 0)
        {
            // 将新接收到的数据追加到累积缓冲区
            memcpy(accum_buffer + accum_length, uart_rx_buffer, length);
            accum_length += length;

            // 检查累积缓冲区中是否包含完整数据包（以'\n'为结束标志）
            char *end_pos;
            while ((end_pos = memchr(accum_buffer, '\n', accum_length)) != NULL)
            {
                size_t packet_length = end_pos - accum_buffer + 1; // 包括结束标志

                // 打印接收到的数据包
                //rt_kprintf("Received data: ");
                /*for(int i = 0; i < packet_length; i++)
                {
                    rt_kprintf("%c", accum_buffer[i]);
                }
                rt_kprintf("\n");*/
                // 查找 "value":1 和 "value":0
                char *value_0_pos = strstr(accum_buffer, "\"value\":0");
                char *value_1_pos = strstr(accum_buffer, "\"value\":1");
                char *value_2_pos = strstr(accum_buffer, "\"value\":2");
                char *value_3_pos = strstr(accum_buffer, "\"value\":3");

                if (value_1_pos != NULL && (value_0_pos == NULL || value_1_pos < value_0_pos))
                {
                    LightSwitch = 1;
                    rt_kprintf("Updated LightSwitch to: %d\n", LightSwitch);
                }
                else if (value_0_pos != NULL)
                {
                    LightSwitch = 0;
                    rt_kprintf("Updated LightSwitch to: %d\n", LightSwitch);
                }
                else if (value_3_pos != NULL && (value_2_pos == NULL || value_3_pos < value_2_pos))
                {
                    rt_pin_write(INA_PIN, PIN_HIGH);
                    rt_pin_write(INB_PIN, PIN_LOW);
                    FanSwitch = 1;
                    rt_kprintf("Updated FanSwitch to ON");
                }
                else if (value_2_pos != NULL)
                {
                    rt_pin_write(INA_PIN, PIN_LOW);
                    rt_pin_write(INB_PIN, PIN_LOW);
                    FanSwitch = 0;
                    rt_kprintf("Updated FanSwitch to OFF");
                }
                else
                {
                    //rt_kprintf("No matching \"value\" found.\n");
                }
                if(LightSwitch) rt_pin_write(LED1_PIN, PIN_LOW);
                else {
                    rt_pin_write(LED1_PIN, PIN_HIGH);
                }

                accum_length -= packet_length;
                memmove(accum_buffer, end_pos + 1, accum_length);
            }
        }
        rt_thread_mdelay(200);
    }
}

void uart_init(void)
{
    rt_err_t result;
    rt_device_t device;

    // 初始化信号量
    rt_sem_init(&rx_sema, "rx_sema", 0, RT_IPC_FLAG_FIFO);

    // 查找串口设备
    device = rt_device_find(UART_NAME);
    if (!device)
    {
        rt_kprintf("find %s failed!\n", UART_NAME);
        return;
    }

    // 打开设备
    result = rt_device_open(device, RT_DEVICE_FLAG_INT_RX);
    if (result != RT_EOK)
    {
        rt_kprintf("open %s failed!\n", UART_NAME);
        return;
    }

    // 设置接收回调函数
    rt_device_set_rx_indicate(device, uart_input);

    //rt_kprintf("uart init success!\n");
    rt_thread_t recv_thread = rt_thread_create("recv",
            uart_receive_and_print,
            RT_NULL,
            2048,
            20, 20);

    if (recv_thread != RT_NULL){
        rt_thread_startup(recv_thread);
    }
}
INIT_APP_EXPORT(uart_init);
