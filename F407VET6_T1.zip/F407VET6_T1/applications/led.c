/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-18     Administrator       the first version
 */
#include <rtthread.h>
#include "rtdevice.h"
#include <rtdbg.h>
#include "board.h"

#define LED1_PIN    GET_PIN(C,12)
#define INA_PIN    GET_PIN(E,8)
#define INB_PIN    GET_PIN(E,9)

void led_init(void)
{
    rt_pin_mode(LED1_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(LED1_PIN, PIN_HIGH);
    //rt_pin_write(LED1_PIN, PIN_LOW);
}
INIT_APP_EXPORT(led_init);

void fan_init(void)
{
    rt_pin_mode(INA_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(INB_PIN, PIN_MODE_OUTPUT);
    //rt_pin_write(INA_PIN, PIN_HIGH);
    //rt_pin_write(INB_PIN, PIN_LOW);
}
INIT_APP_EXPORT(fan_init);

void led1_on(void)
{
    rt_pin_write(LED1_PIN, PIN_LOW);
    rt_kprintf("led1 on\n");
}

void led1_off(void)
{
    rt_pin_write(LED1_PIN, PIN_HIGH);
    rt_kprintf("led1 off\n");
}
