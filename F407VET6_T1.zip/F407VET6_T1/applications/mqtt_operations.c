/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-10     Administrator       the first version
 */

#include <board.h>
#include <rtdevice.h>
#include <rtthread.h>
#include <at_device_esp8266.h>
#include <mqtt_operations.h>
#include <stdio.h>
#include <string.h>
#include "dht11_sample.h"
#include "sensor_rohm_bh1750.h"

//发布消息线程
void mqtt_publish_thread_entry(void *parameter)
{
    rt_uint32_t received_temperature;
    rt_uint32_t received_data;
    struct at_device *device = (struct at_device *) parameter;
    struct at_client *client = device->client;
    at_response_t resp = RT_NULL;

    // 发布的主题和消息内容
    const char *pubtopic = "/sys/k0we6nvqMvX/DHT11/thing/event/property/post";       // 替换为你的发布主题
    const char *msg_temp = "{params:{\\\"Temp\\\":%d}}";

    // 创建响应对象
    resp = at_create_resp(512, 0, 10 * RT_TICK_PER_SECOND);
    if (resp == RT_NULL)
    {
        rt_kprintf("No memory for response create.");
        return -RT_ENOMEM;
    }

    while (1)
    {
        //从邮箱接收数据
/*        if(rt_mb_recv(&mb1, &received_data, RT_WAITING_FOREVER) == RT_EOK) {
                    received_temperature = received_data;
                    rt_thread_mdelay(200);
                }*/
        // 动态生成消息内容
        char msg[64];
        snprintf(msg, sizeof(msg), msg_temp,show_temp);

        // 发布消息
        at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg);
        rt_kprintf("publish temp\n");
/*        if (at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg) != RT_EOK)
        {
            rt_thread_mdelay(1000);
            //rt_kprintf("Failed to publish temp message \n");
            continue;
        }*/
        // 根据需要调整发布频率
        rt_thread_mdelay(1000);
    }
    if (resp)
    {
        at_delete_resp(resp);
    }
}

void mqtt_pubhumi_thread_entry(void *parameter)
{
    rt_uint32_t received_humidity;
    rt_uint32_t received_data;
    struct at_device *device = (struct at_device *) parameter;
    struct at_client *client = device->client;
    at_response_t resp = RT_NULL;

    const char *pubtopic = "/sys/k0we6nvqMvX/DHT11/thing/event/property/post";       // 替换为你的发布主题
    const char *msg_humi = "{params:{\\\"Humi\\\":%d}}";

    resp = at_create_resp(512, 0, 10 * RT_TICK_PER_SECOND);
    if (resp == RT_NULL)
    {
        rt_kprintf("No memory for response create.");
        return;
    }

    while (1)
    {
/*        if(rt_mb_recv(&mb2, &received_data, RT_WAITING_FOREVER) == RT_EOK) {
                        received_humidity = received_data;
                        rt_thread_mdelay(200);
                    }*/
        char msg[64];
        snprintf(msg, sizeof(msg), msg_humi, show_humi);
        at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg);
        rt_kprintf("publish humi\n");
       /* if (at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg) != RT_EOK)
        {
            rt_thread_mdelay(1000);
            rt_kprintf("Failed to publish humi message \n");
            continue;
        }*/
        //rt_kprintf("publish humi !\n");
        rt_thread_mdelay(1000);
    }

    if (resp)
    {
        at_delete_resp(resp);
    }
}

void mqtt_publight_thread_entry(void *parameter)
{
    rt_uint32_t received_lightlux;
    rt_uint32_t received_data;
    struct at_device *device = (struct at_device *) parameter;
    struct at_client *client = device->client;
    at_response_t resp = RT_NULL;

    // 发布的主题和消息内容
    const char *pubtopic = "/sys/k0we6nvqMvX/DHT11/thing/event/property/post";       // 替换为你的发布主题
    const char *msg_lightlux = "{params:{\\\"LightLux\\\":%d}}";

    // 创建响应对象
    resp = at_create_resp(512, 0, 10 * RT_TICK_PER_SECOND);
    if (resp == RT_NULL)
    {
        rt_kprintf("No memory for response create.");
        return;
    }

    while (1)
    {
/*        if(rt_mb_recv(&lightlux_mailbox, &received_data, RT_WAITING_FOREVER) == RT_EOK) {
                    received_lightlux = received_data;
                    show_light = received_lightlux;
                    rt_thread_mdelay(1000);
                }*/
        // 动态生成消息内容
        char msg[64];
        snprintf(msg, sizeof(msg), msg_lightlux, show_light);
        at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg);
        rt_kprintf("publish Light intensity\n");
       /* if (at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg) != RT_EOK)
        {
            rt_thread_mdelay(1000);
            //rt_kprintf("Failed to publish light message \n");
            continue;
        }*/
        rt_thread_mdelay(500);
    }

    if (resp)
    {
        at_delete_resp(resp);
    }
}

void mqtt_pubAQI_thread_entry(void *parameter)
{
    struct at_device *device = (struct at_device *) parameter;
    struct at_client *client = device->client;
    at_response_t resp = RT_NULL;

    const char *pubtopic = "/sys/k0we6nvqMvX/DHT11/thing/event/property/post";       // 替换为你的发布主题
    const char *msg_humi = "{params:{\\\"AQI\\\":%d}}";

    resp = at_create_resp(512, 0, 10 * RT_TICK_PER_SECOND);
    if (resp == RT_NULL)
    {
        rt_kprintf("No memory for response create.");
        return;
    }

    while (1)
    {

        char msg[64];
        snprintf(msg, sizeof(msg), msg_humi, mq135_status);
        at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg);
        rt_kprintf("publish AQI\n");
/*        if (at_obj_exec_cmd(client, resp, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", pubtopic, msg) != RT_EOK)
        {
            rt_thread_mdelay(1000);
            //rt_kprintf("Failed to publish humi message to topic %s. Response: %s", pubtopic, resp->buf);
            continue;
        }*/

        rt_thread_mdelay(1000);
    }

    if (resp)
    {
        at_delete_resp(resp);
    }
}
