// index.js
var mqtt=require('../../utils/mqtt.min.js')
const crypto = require('../../utils/hex_hmac_sha1.js') //根据自己存放的路径修改

Page({
  data: {
    intervalId: null,
    cityName: '正在获取位置',
    cityId: null,
    weather: null,
    airQuality: null,
    errorMessage:'',
    switch1Checked:false,
    switch2Checked:false,
    airQualityStatus: '',
    getAQI:null,
    getTemp:null,
    getHumid:null,
    getLight:null
  },
  doConnect: function() {
    const deviceConfig = {
      productKey: "k0we6nvqMvX",
      deviceName: "android",
      deviceSecret: "f10f2f5c1d3c521d862b06790a74f3d9",
      regionId: "cn-shanghai"
    };
    const options = this.initMqttOptions(deviceConfig);
    options.keepAliveInterval = 60; // 调整这个值，确保它适合你的应用需求
    options.cleanSession = true; // 如果不需要持久会话
    // 将 client 存储为页面实例的一个属性
    this.client = mqtt.connect('wxs://k0we6nvqMvX.iot-as-mqtt.cn-shanghai.aliyuncs.com', options);
    this.client.on('connect', () => {
      console.log('连接服务器成功');
      this.client.subscribe('/k0we6nvqMvX/android/user/get', (err) => {
        if (!err) {
          console.log('订阅成功！');
        }
      });
    });

    this.client.on('reconnect', () => {
      console.log('MQTT 正在重连');
    });

    this.client.on('close', () => {
      console.log('MQTT 连接关闭');
      if (!this.client.reconnecting) {
        console.log('正在尝试重连');
        setTimeout(() => this.doConnect(), 2000); // 2秒后尝试重连
    }
    });

    this.client.on('error', (error) => {
      console.error('MQTT 连接错误:', error);
    });

    this.client.on('message', (topic, message) => {
      let msg = message.toString();
      let tem = JSON.parse(msg);
      console.log(tem.items);
      if (tem.items) {
        console.log('准备更新数据');
        let updateData = {};
        if (tem.items.Temp) updateData.getTemp = tem.items.Temp.value;
        if (tem.items.LightLux) updateData.getLight = tem.items.LightLux.value;
        if (tem.items.Humi) updateData.getHumid = tem.items.Humi.value;
        if (tem.items.LightSwitch) updateData.switch1Checked = tem.items.LightSwitch.value;
        if (tem.items.AQI) updateData.getAQI = tem.items.AQI.value;
        this.setData(updateData, () => {
          console.log('After setData:', this.data);
        });
      }
    });
  },    
  onLoad: function () {
    //注意：这里在程序运行后会直接进行连接，如果你要真机调试，记得关掉模拟器或者使用一个按钮来控制连接，以避免模拟器和真机同时进行连接导致两边都频繁断线重连！
      this.getLocation()
      const cityName = this.data.cityName;
      console.log('最终的城市名称:', cityName);      //首次获取不到最新的城市名称，用定时器执行几次，获取到最新的cityName
      let count = 0;
      const interval = 2000; // 时间间隔，单位为毫秒
      this.data.intervalId = setInterval(() => {
      console.log(`定时器触发`);
      this.getCityId(this.data.cityName);
      this.fetchAirQuality(this.data.cityId); // 城市ID
      this.fetchWeather(this.data.cityId);
      count++; // 每次触发时增加计数
      if (count >= 3) { // 如果计数达到了3
        clearInterval(this.data.intervalId); // 清除定时器
        console.log('定时器已停止');
      }
      }, interval);
      // this.fetchAirQuality(101050101); 
      // this.fetchWeather(101050101);

      this.doConnect()
  },

  getLocation() {
    const self = this;
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.userLocation']) {
          wx.authorize({
            scope: 'scope.userLocation',
            success() {
              self.fetchLocation();
            },
            fail() {
              self.setData({ cityName: '未授权位置信息' });
            }
          });
        } else {
          self.fetchLocation();
        }
      }
    });
  },
  fetchLocation() {
    const self = this;
    wx.getLocation({
      type: 'wgs84',           // 默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标
      success(res) {
        const latitude = res.latitude;
        const longitude = res.longitude;
        //console.log(latitude)
        //console.log(longitude)
        self.reverseGeocoder(latitude,longitude);
      },
      fail() {
        self.setData({ cityName: '获取位置失败' });
      }
    });
  },
  //自动定位获取城市
  reverseGeocoder(latitude, longitude) {
    const map_key = "JC2BZ-QW7WQ-TXX52-2WZJV-ANI3H-72BQO";
    const self = this;
    wx.request({
       url: `https://apis.map.qq.com/ws/geocoder/v1?location=${latitude},${longitude}&key=${map_key}`, 
      success(res) {
        if (res.data.status === 0) { // 请求成功
          const city = res.data.result.address_component.city;
          self.setData({ cityName: city });
        } else {
          self.setData({ cityName: '无法确定城市' });
        }
      },
      fail() {
        self.setData({ cityName: '获取城市信息失败' });
      }
    });
  },

  getCityId(cityName) {
    let processedCityName = cityName.replace(/市$/, '');
    const apikey='9f053f1e886344dcbc9aff0016a015fd';
    console.log('处理后的城市名称:', processedCityName);
    wx.request({
      url: `https://geoapi.qweather.com/v2/city/lookup?location=${processedCityName}&key=${apikey}`,
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200 && res.data.code === '200') {
          const Id = res.data.location[0].id;
          console.log(`城市ID为：${Id}`);
          this.setData({ cityId:Id });
        } else {
          console.error('获取城市ID失败');
        }
      },
      fail: (err) => {
        console.error('请求失败', err);
      }
    });
  },

//和风天气api获取AQI数据
  fetchAirQuality: function(location) {
    const apiKey = '9f053f1e886344dcbc9aff0016a015fd'; // 替换为你的API密钥
    wx.request({
      url: `https://devapi.qweather.com/v7/air/now?location=${location}&key=${apiKey}`,
      method: 'GET',
      success: res => {
        if (res.statusCode === 200) {
          const airQualityData = res.data.now;
          const status = this.getAirQualityStatus(airQualityData.aqi);
          this.setData({ 
            airQuality: airQualityData, 
            airQualityStatus: status, 
            errorMessage: '' 
          });
        } else {
          this.setData({ errorMessage: '请求失败，请检查网络连接或API密钥是否正确' });
        }
      },
      fail: err => {
        console.error('请求失败', err);
        this.setData({ errorMessage: '请求发生错误，请稍后重试' });
      }
    });
  },
  //和风天气api获取天气数据
  fetchWeather: function(location) {
    const apiKey = '9f053f1e886344dcbc9aff0016a015fd'; // 替换为你的API密钥
    wx.request({
      url: `https://devapi.qweather.com/v7/weather/now?location=${location}&key=${apiKey}`,
      method: 'GET',
      success: res => {
        if (res.statusCode === 200) {
          const weatherData = res.data.now;
          this.setData({ 
            weather: weatherData, 
            errorMessage: '' 
          });
        } else {
          this.setData({ errorMessage: '请求失败，请检查网络连接或API密钥是否正确' });
        }
      },
      fail: err => {
        console.error('请求失败', err);
        this.setData({ errorMessage: '请求发生错误，请稍后重试' });
      }
    });
  },
  getAirQualityStatus: function(aqi) {
    if (aqi >= 0 && aqi <= 50) return '优';
    else if (aqi >= 51 && aqi <= 100) return '良';
    else if (aqi >= 101 && aqi <= 150) return '轻度污染';
    else if (aqi >= 151 && aqi <= 200) return '中度污染';
    else if (aqi >= 201 && aqi <= 300) return '重度污染';
    else if (aqi >= 301 && aqi <= 500) return '严重污染';
    else return '未知';
  },
  
  switch1Change:function(event){
    const payloadOn = JSON.stringify({
      id: Date.now(), // 使用当前时间戳作为消息ID
      version: "1.0",
      sys: { ack: 1 },
      params: {
          LightSwitch: {
              value: 1, // 开关状态
              time: new Date().getTime() // 当前时间的时间戳
          }
      },
      method: "thing.event.property.post"
  });
  const payloadOff = JSON.stringify({
    id: Date.now(), // 使用当前时间戳作为消息ID
    version: "1.0",
    sys: { ack: 1 },
    params: {
        LightSwitch: {
            value: 0, // 开关状态
            time: new Date().getTime() // 当前时间的时间戳
        }
    },
    method: "thing.event.property.post"
});
    console.log(event.detail)
    let sw=event.detail.value
    console.log(event.detail.value)
    if(sw)
    {
        //属性上报
        this.client.publish('/sys/k0we6nvqMvX/android/thing/event/property/post',payloadOn,function(err){
       if(!err)
       {
         console.log(payloadOn)
         console.log('成功发送指令-开')
       }
     })
    }
    else
    {
      this.client.publish('/sys/k0we6nvqMvX/android/thing/event/property/post',payloadOff,function(err){
       if(!err)
       {
         console.log('成功发送指令-关')
       }
     })
    }
  },

  switch2Change:function(event){
    const payloadOn = JSON.stringify({
      id: Date.now(), // 使用当前时间戳作为消息ID
      version: "1.0",
      sys: { ack: 1 },
      params: {
          FanSwitch: {
              value: 3, // 开状态
              time: new Date().getTime() // 当前时间的时间戳
          }
      },
      method: "thing.event.property.post"
  });
  const payloadOff = JSON.stringify({
    id: Date.now(), // 使用当前时间戳作为消息ID
    version: "1.0",
    sys: { ack: 1 },
    params: {
        FanSwitch: {
            value: 2, // 关状态
            time: new Date().getTime() // 当前时间的时间戳
        }
    },
    method: "thing.event.property.post"
});
    console.log(event.detail)
    let sw=event.detail.value
    console.log(event.detail.value)
    if(sw)
    {
        //属性上报
        this.client.publish('/sys/k0we6nvqMvX/android/thing/event/property/post',payloadOn,function(err){
       if(!err)
       {
         console.log('成功发送指令-开')
       }
     })
    }
    else
    {
      this.client.publish('/sys/k0we6nvqMvX/android/thing/event/property/post',payloadOff,function(err){
       if(!err)
       {
         console.log('成功发送指令-关')
       }
     })
    }
  },
  

  //IoT平台mqtt连接参数初始化
 initMqttOptions(deviceConfig) {

    const params = {
      productKey: deviceConfig.productKey,
      deviceName: deviceConfig.deviceName,
      timestamp: Date.now(),
      clientId: Math.random().toString(36).substr(2),
    }
    //CONNECT参数
    const options = {
      keepalive: 120, //120s
      clean: true, //cleanSession不保持持久会话
      protocolVersion: 4 //MQTT v3.1.1
    }
    //1.生成clientId，username，password
    options.password = this.signHmacSha1(params, deviceConfig.deviceSecret);
    options.clientId = `${params.clientId}|securemode=2,signmethod=hmacsha1,timestamp=${params.timestamp}|`;
    options.username = `${params.deviceName}&${params.productKey}`;

    return options;
  },
  /*
  生成基于HmacSha1的password
  参考文档：https://help.aliyun.com/document_detail/73742.html?#h2-url-1
*/
 signHmacSha1(params, deviceSecret) {

  let keys = Object.keys(params).sort();
  // 按字典序排序
  keys = keys.sort();
  const list = [];
  keys.map((key) => {
    list.push(`${key}${params[key]}`);
  });
  const contentStr = list.join('');
  return crypto.hex_hmac_sha1(deviceSecret, contentStr);
}
})
